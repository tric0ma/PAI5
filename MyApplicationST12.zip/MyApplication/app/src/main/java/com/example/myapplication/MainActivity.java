package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import java.util.HashMap;
import java.util.Map;




public class MainActivity extends AppCompatActivity {

    // Setup Server information
    protected static String server = "10.0.2.2";
    protected static int port = 7070;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Capturamos el boton de Enviar
        View button = findViewById(R.id.button_send);

        // Llama al listener del boton Enviar
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });


    }

    // Creación de un cuadro de dialogo para confirmar pedido
    private void showDialog() throws Resources.NotFoundException {
        EditText camas = findViewById(R.id.camasNumberID);
        EditText sillas = findViewById(R.id.sillasNumberID);
        EditText sillones = findViewById(R.id.sillonesNumberID);
        EditText toallas = findViewById(R.id.toallasNumberID);


        if (camas.getText().toString().isEmpty() ||
                sillas.getText().toString().isEmpty() ||
                sillones.getText().toString().isEmpty() ||
                toallas.getText().toString().isEmpty()) {
            // Mostramos un mensaje emergente;
            Toast.makeText(getApplicationContext(), "No puedes enviar campos vacíos, indica con un 0 los que lo estén", Toast.LENGTH_SHORT).show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Enviar")
                    .setMessage("Se va a proceder al envio")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                // Catch ok button and send information
                                public void onClick(DialogInterface dialog, int whichButton) {

                                    // 1. Extraer los datos de la vista
                                    String camasInput = camas.getText().toString();
                                    int camasNumber = Integer.parseInt(camasInput);
                                    String sillasInput = sillas.getText().toString();
                                    int sillasNumber = Integer.parseInt(sillasInput);
                                    String sillonesInput = sillones.getText().toString();
                                    int sillonesNumber = Integer.parseInt(sillonesInput);
                                    String toallasInput = toallas.getText().toString();
                                    int toallasNumber = Integer.parseInt(toallasInput);




                                    // 2. Firmar los datos

                                    // 3. Enviar los datos
                                    String url = "http://10.0.2.2/api/enviar_datos";
                                    RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

                                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    // Manejar la respuesta del servidor
                                                    Toast.makeText(MainActivity.this,
                                                            "Petición enviada correctamente",
                                                            Toast.LENGTH_SHORT).show();
                                                }
                                            },
                                            new Response.ErrorListener() {
                                                @Override
                                                public void onErrorResponse(VolleyError error) {
                                                    // Manejar errores de la solicitud
                                                    Toast.makeText(MainActivity.this,
                                                            "Error al enviar la petición",
                                                            Toast.LENGTH_SHORT).show();
                                                }
                                            }) {
                                        @Override
                                        protected Map<String, String> getParams() {
                                            Map<String, String> params = new HashMap<>();
                                            params.put("camas", String.valueOf(camasNumber));
                                            params.put("sillas", String.valueOf(sillasNumber));
                                            params.put("sillones", String.valueOf(sillonesNumber));
                                            params.put("toallas", String.valueOf(toallasNumber));
                                            return params;
                                        }
                                    };

                                    queue.add(stringRequest);

                                    Toast.makeText(MainActivity.this, "Petición enviada correctamente", Toast.LENGTH_SHORT).show();
                                }
                            }

                    )
                    .

                            setNegativeButton(android.R.string.no, null)

                    .

                            show();
        }
    }


}
