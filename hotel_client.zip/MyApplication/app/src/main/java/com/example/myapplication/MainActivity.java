package com.example.myapplication;

import android.content.res.Resources;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import android.util.Base64;
import java.net.Socket;
import java.security.cert.CertificateFactory;
import java.security.cert.Certificate;
import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.DataOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class MainActivity extends AppCompatActivity {

    // Setup Server information
    protected static String server = "192.168.1.32";
    protected static int port = 7070;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Capturamos el boton de Enviar
        View button = findViewById(R.id.button_send);

        // Llama al listener del boton Enviar
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });


    }

    // Creación de un cuadro de dialogo para confirmar pedido
    private void showDialog() throws Resources.NotFoundException {

        //Extraemos los valores de los ID de la vista
        EditText camas = (EditText) findViewById(R.id.camasNumberID);
        EditText sillas = (EditText) findViewById(R.id.sillasNumberID);
        EditText sillones = (EditText) findViewById(R.id.sillonesNumberID);
        EditText toallas = (EditText) findViewById(R.id.toallasNumberID);
        EditText employee = (EditText) findViewById(R.id.employerID);

        new AlertDialog.Builder(this)
                .setTitle("Enviar")
                .setMessage("Se va a proceder al envio")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                // 1. Extraer los datos de la vista
                                //Pasamos a String los valores de los inputs
                                String camas_string =  camas.getText().toString();
                                String sillas_string =  sillas.getText().toString();
                                String sillones_string =  sillones.getText().toString();
                                String toallas_string =  toallas.getText().toString();
                                String empleado_string =  employee.getText().toString();

                                // Variable para controlar el numero máximo de pedidos
                                int maxNumItems = 300;

                                //Validamos que los valores no estén vacíos
                                if  ((camas_string.isEmpty() &&
                                        sillas_string.isEmpty() &&
                                        sillones_string.isEmpty() &&
                                        toallas_string.isEmpty()) ||
                                        empleado_string.isEmpty()) {

                                    //Log validación fallida por campos vacíos
                                    Toast.makeText(getApplicationContext(),
                                            "No se puede enviar la lista vacía (al menos un pedido) " +
                                                    "y/o sin identificador del empleado", Toast.LENGTH_SHORT).show();
                                    //Validación de pedidos no superiores a 300 elementos
                                }   else if ((Integer.parseInt(camas_string) > maxNumItems) ||
                                        (Integer.parseInt(sillas_string) > maxNumItems) ||
                                        (Integer.parseInt(sillones_string) > maxNumItems) ||
                                        (Integer.parseInt(toallas_string) > maxNumItems)) {

                                    //Log validacion fallida por exceso de pedidos
                                    Toast.makeText(getApplicationContext(),
                                            "El pedido no puede contener más de 300 unidades de " +
                                                    "ningún recurso, intente de nuevo con menos cantidad",
                                            Toast.LENGTH_SHORT).show();

                                }   else {

                                    //String con todos los datos
                                    String dataObjects = camas_string + " | " +
                                            sillas_string + " | " +
                                            sillones_string + " | " +
                                            toallas_string + " | " +
                                            empleado_string;
                                    try {
                                        // 2. Firmar los datos
                                        String firma = firmarDatos(dataObjects, empleado_string);
                                        String datosYFirma = dataObjects + "---" + firma;
                                        // 3. Enviar los datos
                                        enviarDatos(datosYFirma);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        //Log de error al usar firma no válida
                                        Toast.makeText(MainActivity.this, "Error en el " +
                                                "firmado de los datos solicitados:\n" + e, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                )
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    //Función para firmar los datos con la clave en formato .pem del empleado
    private String firmarDatos(String dataObject, String employeeID) throws Exception {

        //Nombre del archivo de la clave con la que el cliente firma
        //Sustituir aqui la nueva firma para probar los nuevos clientes
        String archivoClaveFirma = "KEY-58883.pem";
        //Buscamos en la nueva carpeta "Assets" el archivo anterior
        InputStream keyInputStream = getAssets().open(archivoClaveFirma);
        //Array de bytes de la firma
        byte[] keyBytes = lecturaBytes(keyInputStream);
        //Tomamos la clave sin los limitadores del archivo
        String keyString = new String(keyBytes).replaceAll("-----\\w+ PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        //Decodificamos clave
        byte[] claveDec = Base64.decode(keyString, Base64.DEFAULT);
        PKCS8EncodedKeySpec PKCS = new PKCS8EncodedKeySpec(claveDec);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = kf.generatePrivate(PKCS);
        //Firmado de información
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(privateKey);
        sig.update(dataObject.getBytes());
        //Firma
        byte[] signedData = sig.sign();
        //Firma en base64
        return Base64.encodeToString(signedData, Base64.DEFAULT);
    }

    //Función necesaria para generar array de bytes del string de datos finales
    private byte[] lecturaBytes(InputStream inputStream) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            StringBuilder stringBuilder = new StringBuilder();
            String l;
            while ((l = reader.readLine()) != null) {
                stringBuilder.append(l).append("\n");
            }
            return stringBuilder.toString().getBytes();
        }
    }

    private void enviarDatos(String data) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... params) {
                String serverResponse = "";

                try {
                    SSLContext sslContext = SSLContext.getInstance("TLSv1.3");
                    TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());

                    // Cargar certificado del servidor
                    InputStream archivoCRT = getResources().openRawResource(R.raw.server);
                    CertificateFactory cf = CertificateFactory.getInstance("X.509");
                    Certificate cert = cf.generateCertificate(archivoCRT);
                    archivoCRT.close();

                    // Configurar KeyStore con el certificado del servidor
                    ks.load(null, null);
                    ks.setCertificateEntry("server", cert);
                    tmf.init(ks);

                    // Inicializar SSLContext con el KeyStore
                    sslContext.init(null, tmf.getTrustManagers(), null);

                    // Establecer conexión segura con el servidor
                    SSLSocketFactory socketFactory = sslContext.getSocketFactory();
                    try (SSLSocket socket = (SSLSocket) socketFactory.createSocket(server, port)) {
                        socket.startHandshake();

                        // Enviar dato al servidor
                        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
                        output.writeUTF(params[0]);
                        output.flush();

                        // Recibir respuesta del servidor
                        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        serverResponse = input.readLine();
                    }
                } catch (Exception e) {
                    if (!"Socket cerrado".equals(e.getMessage())) {
                        e.printStackTrace();
                        serverResponse = "*¡Error!*: " + e.getMessage();
                    }
                }
                return serverResponse;
            }

            @Override
            protected void onPostExecute(String result) {
                Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
            }
        }.execute(data);
    }

}